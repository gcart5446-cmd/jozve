@echo off
cd /d "%~dp0demo-library"
set N=0
for /r /d %%D in (*) do (
  if exist "%%D\desktop.ini" (
    attrib +s +h "%%D\desktop.ini"
    set /a N+=1
  )
)
echo Done - folder icons enabled on %N% folders.
pause
